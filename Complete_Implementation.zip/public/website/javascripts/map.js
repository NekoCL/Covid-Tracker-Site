mapboxgl.accessToken = 'pk.eyJ1IjoiZWRiZW5jaCIsImEiOiJja29qbnY0c2oxZHI1Mm9vOXE2ejJndmZlIn0.ZwPX7lBKL94Op5DPXF7bew';
var map = new mapboxgl.Map({
    container: 'map', // container ID
    style: 'mapbox://styles/mapbox/streets-v11', // style URL
    center: [138.364, -34.5544], // starting position [lng, lat]
    zoom: 9 // starting zoom
});

//Fly to
map.flyTo({center: [138.6, -34.9], zoom: 10});

//Marker
var marker = new mapboxgl.Marker()
.setLngLat([138.6, -34.95])
.addTo(map);

var marker2 = new mapboxgl.Marker()
.setLngLat([138.59, -34.91])
.addTo(map);

var marker3 = new mapboxgl.Marker({
color: "#ff0000",
draggable: false
}).setLngLat([138.59, -34.93])
.addTo(map);