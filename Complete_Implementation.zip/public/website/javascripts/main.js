 // Open modal when user clicks login button
document.getElementById("userLoginBtn").onclick = function() {
    document.getElementById("userModal").style.display = "block";
};
document.getElementById("ownerLoginBtn").onclick = function() {
    document.getElementById("ownerModal").style.display = "block";
};
document.getElementById("adminLoginBtn").onclick = function() {
    document.getElementById("adminModal").style.display = "block";
};

// Open modal for choosing sign up account type
document.getElementById("signUpBtn").onclick = function() {
    document.getElementById("signUpModal").style.display = "block";
};

// Clicking outside the modal box or clicking the (x) closes it
window.onclick = function(event) {
    //Click outside
    if (event.target == document.getElementById("userModal")) {
      document.getElementById("userModal").style.display = "none";
    }
    if (event.target == document.getElementById("ownerModal")) {
      document.getElementById("ownerModal").style.display = "none";
    }
    if (event.target == document.getElementById("adminModal")) {
      document.getElementById("adminModal").style.display = "none";
    }

    //Click x
    if (event.target == document.getElementById("close-x")) {
      document.getElementById("userModal").style.display = "none";
    }
    if (event.target == document.getElementById("close2-x")) {
      document.getElementById("ownerModal").style.display = "none";
    }
    if (event.target == document.getElementById("close3-x")) {
      document.getElementById("adminModal").style.display = "none";
    }

    //Click outside
    if (event.target == document.getElementById("ownerModal")) {
      document.getElementById("ownerModal").style.display = "none";
    }
    //Click x
    if (event.target == document.getElementsByClassName("close-x4")) {
      document.getElementById("ownerModal").style.display = "none";
    }

    //Click outside
    if (event.target == document.getElementById("signUpModal")) {
      document.getElementById("signUpModal").style.display = "none";
    }
    //Click cancel
    if (event.target == document.getElementById("cancelSign")) {
      document.getElementById("signUpModal").style.display = "none";
    }

};

/* get timestamp for admin.html */
function getUpdates() {
    var d = new Date();
    document.getElementById("timestamp").innerHTML = "Latest data updated on " + d;
}

/* array to display in GET later */
var user_table = [];
var owner_table = [];
var hotspot_table = [];
var checkin_table = [];
var business_table = [];
var biz_table = [];

/*function createUsers(){

    var username = document.getElementById("user_username").value;
    var email = document.getElementById("user_email").value;
    var first_name = document.getElementById("user_firstname").value;
    var last_name = document.getElementById("user_lastname").value;
    var address = document.getElementById("user_address").value;
    var number = document.getElementById("user_number").value;
    var password = document.getElementById("user_password").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Registration Successful!");
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Please try again");
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/usersignup", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({username, email, first_name, last_name, address, number, password}));

}*/

function createUsers(){
    console.log('function create users');

    var username = document.getElementById("user_username").value;
    var email = document.getElementById("user_email").value;
    var first_name = document.getElementById("user_firstname").value;
    var last_name = document.getElementById("user_lastname").value;
    var address = document.getElementById("user_address").value;
    var zip = document.getElementById("user_zip").value;
    var dob = document.getElementById("user_dob").value;
    var number = document.getElementById("user_number").value;
    var password = document.getElementById("user_password").value;
    var email_notif = '';
    if(document.getElementById("emailnotif").checked) {
        email_notif = 'Yes';
    } else {
        email_notif = 'No';
    }
    console.log('email_notif '+email_notif);

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Registration Successful!");
            window.location.href = "/index.html";
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Please try again, Username is taken");
        } else {
            console.log('cr else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/usersignup", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({username, email, first_name, last_name, address, zip, dob, number, password, email_notif}));

}

function createOwners(){

    var usernameOwn = document.getElementById("owner_username").value;
    var emailOwn = document.getElementById("owner_email").value;
    var first_nameOwn = document.getElementById("owner_firstname").value;
    var last_nameOwn= document.getElementById("owner_lastname").value;
    var addressOwn = document.getElementById("owner_address").value;
    var zipOwn = document.getElementById("owner_zip").value;
    var dobOwn = document.getElementById("owner_dob").value;
    var numberOwn = document.getElementById("owner_number").value;
    var passwordOwn = document.getElementById("owner_password").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Registration Successful!");
            window.location.href = "/index.html";
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Please try again, Username or Email is taken");
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/ownersignup", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({usernameOwn, emailOwn, first_nameOwn, last_nameOwn, addressOwn, zipOwn, dobOwn, numberOwn, passwordOwn}));

}

function createAdmins(){

    var usernameAdm = document.getElementById("admin_username").value;
    var emailAdm = document.getElementById("admin_email").value;
    var first_nameAdm = document.getElementById("admin_firstname").value;
    var last_nameAdm = document.getElementById("admin_lastname").value;
    var passwordAdm = document.getElementById("admin_password").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Registration Successful!");
            window.location.href = "/admin.html";
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Please try again, Username is taken");
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/adminsignup", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({usernameAdm, emailAdm, first_nameAdm, last_nameAdm, passwordAdm}));

}

/* Get hotspot total for dashboard */
function getHotspotTotal() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

           var hotspot_table = JSON.parse(this.responseText);

           // display all data
           for(var i=0; i<hotspot_table.length; i++){
                document.getElementById("total-hotspot").innerHTML = hotspot_table[i].totalspot;
           }

        }
    };


    // Open connection to server
    xmlhttp.open("GET", "/totalhotspot", true);

    // Send request
    xmlhttp.send();

}

/* Get venue total for dashboard */
function getVenueInTotal() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

            var venue_table = JSON.parse(this.responseText);
            document.getElementById("total-venues").innerHTML = venue_table[0].totalvenue;

        }
    };

    // Open connection to server
    xmlhttp.open("GET", "/totalvenues", true);

    // Send request
    xmlhttp.send();

}

/* Get restriction */
function getRestrictions() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

            var restrict_table = JSON.parse(this.responseText);
            document.getElementById("restrict-state").innerHTML = `<h3>Restrictions in place: `+restrict_table[0].resbool+`</h3>`;

        }
    };

    // Open connection to server
    xmlhttp.open("GET", "/users/restrictioninfo", true);

    // Send request
    xmlhttp.send();

}

/* Create hotspot */
function createHotspot(){

    var hotspotu = document.getElementById("hotspot-zip-input").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Hotspot added!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to add hotspot");
        } else {
            console.log('hs else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/addhotspot", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({hotspotu}));

}

/* Remove hotspot */
function removeHotspot(){

    var hotspotr = document.getElementById("hotspot-zip-input-remove").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Hotspot removed!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to remove hotspot");
        } else {
            console.log('hs else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/removehotspot", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({hotspotr}));

}

/* Get Owner Name */
function getOwnerName() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

            owner_table = JSON.parse(this.responseText);
            document.getElementById("greet_owner").innerHTML = "Hey, " + owner_table[0].first_name + " " + owner_table[0].last_name + "!";

        }
    };

    // Open connection to server
    xmlhttp.open("GET", "/getOwner", true);

    // Send request
    xmlhttp.send();

}

/* Display Business Table */
function showBizTable() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

           biz_table = JSON.parse(this.responseText);

            document.getElementById("show_name").innerHTML = '';
            document.getElementById("show_name").innerHTML += `<tr><th>Name</th><th>Code</th></tr>`;

           // display all data on the cards
           for(var i=0; i<biz_table.length; i++){
                // venue 1
                document.getElementById("show_name").innerHTML += `<tr><td>`+biz_table[i].name+`</td>
                                                                    <td>`+biz_table[i].business_code+`</td></tr>`;
                }
           }
        };


    // Open connection to server
    xmlhttp.open("GET", "/getBizTable", true);

    // Send request
    xmlhttp.send();

}


/* Display venue 1 */
function getBusiness() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

           business_table = JSON.parse(this.responseText);


                // display all data on the cards
                for(var i=0; i<business_table.length; i++){
                // venue 1
                document.getElementById("venue1_name").innerHTML = business_table[0].name;
                document.getElementById("venue1_size").innerHTML = "Size (sq.m):<br>" + "<em>" + business_table[0].b_size + "</em>";
                document.getElementById("venue1_type").innerHTML = "Business Type:<br>" + "<em>" + business_table[0].b_type + "</em>";
                document.getElementById("venue1_cap").innerHTML = "Capacity (pax):<br>" + "<em>" + business_table[0].b_cap + " (Set by Admin)</em>";
                document.getElementById("code_1").innerHTML = "Venue Code:<br>" + "<em>" + business_table[0].b_code + "</em>";
                // venue 2
                document.getElementById("venue2_name").innerHTML = business_table[1].name;
                document.getElementById("venue2_size").innerHTML = "Size (sq.m):<br>" + "<em>" + business_table[1].b_size + "</em>";
                document.getElementById("venue2_type").innerHTML = "Business Type:<br>" + "<em>" + business_table[1].b_type + "</em>";
                document.getElementById("venue2_cap").innerHTML = "Capacity (pax):<br>" + "<em>" + business_table[1].b_cap + " (Set by Admin)</em>";
                document.getElementById("code_2").innerHTML = "Venue Code:<br>" + "<em>" + business_table[1].b_code + "</em>";
                // venue 3
                document.getElementById("venue3_name").innerHTML = business_table[2].name;
                document.getElementById("venue3_size").innerHTML = "Size (sq.m):<br>" + "<em>" + business_table[2].b_size + "</em>";
                document.getElementById("venue3_type").innerHTML = "Business Type:<br>" + "<em>" + business_table[2].b_type + "</em>";
                document.getElementById("venue3_cap").innerHTML = "Capacity (pax):<br>" + "<em>" + business_table[2].b_cap + " (Set by Admin)</em>";
                document.getElementById("code_3").innerHTML = "Venue Code:<br>" + "<em>" + business_table[2].b_code + "</em>";
                }
           }
        };


    // Open connection to server
    xmlhttp.open("GET", "/startownerpage", true);

    // Send request
    xmlhttp.send();

}

/* Edit Business Card 1 */
function editBusiness1(){

    var rename = document.getElementById("biz_name1").value;
    var resize = document.getElementById("biz_size1").value;
    var retype = document.getElementById("biz_type1").value;
    var oldname = document.getElementById("venue1_name").innerHTML;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('hs else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/editbusiness1", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({rename, resize, retype, oldname}));

}

/* Edit Business Card 2 */
function editBusiness2(){

    var rename2 = document.getElementById("biz_name2").value;
    var resize2 = document.getElementById("biz_size2").value;
    var retype2 = document.getElementById("biz_type2").value;
    var oldname2 = document.getElementById("venue2_name").innerHTML;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('hs else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/editbusiness2", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({rename2, resize2, retype2, oldname2}));

}

/* Edit Business Card 3 */
function editBusiness3(){

    var rename3 = document.getElementById("biz_name3").value;
    var resize3 = document.getElementById("biz_size3").value;
    var retype3 = document.getElementById("biz_type3").value;
    var oldname3 = document.getElementById("venue3_name").innerHTML;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('hs else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/editbusiness3", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({rename3, resize3, retype3, oldname3}));

}

/* Add Business */
function addBusiness(){
    console.log('create new business');

    var bus_name = document.getElementById("newBname").value;
    var bus_size = document.getElementById("newBsize").value;
    var bus_type = document.getElementById("newBtype").value;
    var bus_num = document.getElementById("newBnum").value;
    var bus_add = document.getElementById("newBadd").value;
    var bus_zip = document.getElementById("newBzip").value;
    var bus_code = document.getElementById("newBcode").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("New Business Added");
            window.location.href = "/index.html";
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Please try again");
        } else {
            console.log('cr else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/newbusiness", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({bus_name, bus_size, bus_type, bus_num, bus_add, bus_zip, bus_code}));

}

/* Remove Business 1 */
function removeBiz(){

    var remove_bus1 = document.getElementById("venue1_name").innerHTML;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Business Removed");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to remove");
        } else {
            console.log('hs else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/removebiz1", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({remove_bus1}));

}

/* Remove Business 2 */
function removeBiz2(){

    var remove_bus2 = document.getElementById("venue2_name").innerHTML;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Business Removed");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to remove");
        } else {
            console.log('hs else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/removebiz2", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({remove_bus2}));

}

/* Remove Business 3 */
function removeBiz3(){

    var remove_bus3 = document.getElementById("venue3_name").innerHTML;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Business Removed");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to remove");
        } else {
            console.log('hs else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/removebiz3", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({remove_bus3}));
}

function userLogin(){
    let users = {
        user: document.getElementById('user_username_login').value,
        pass: document.getElementById('user_password_login').value
    };
    console.log(users);

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href = "/user.html";
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Login failed");
        } else {
            console.log(this.responseText);
            console.log('else');
        }
    };

    xmlhttp.open("POST", "/userlogin", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify(users));
}

function ownerLogin(){
    let users = {
        user: document.getElementById('owner_username_login').value,
        pass: document.getElementById('owner_password_login').value
    };
    console.log(users);

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href = "/owner.html";
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Login failed");
        }
    };

    xmlhttp.open("POST", "/ownerlogin", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify(users));
}

function adminLogin(){
    let users = {
        user: document.getElementById('admin_username_login').value,
        pass: document.getElementById('admin_password_login').value
    };

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            window.location.href = "/admin.html";
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Login failed");
        } else {
            console.log('ready else');
        }
    };

    xmlhttp.open("POST", "/adminlogin", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify(users));
}

function logout(){

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    window.location.href = "/index.html";
    xmlhttp.open("POST", "/logout", true);
    xmlhttp.send();

}

// function signOut() {
//     var auth2 = gapi.auth2.getAuthInstance();
//     auth2.signOut().then(function () {
//       console.log('User signed out.');

//       var xmlhttp = new XMLHttpRequest();

//     window.location.href = "/index.html";
//     xmlhttp.open("POST", "/users/logout", true);
//     xmlhttp.send();
//     });
// }


function onSignIn(googleUser) {
  var profile = googleUser.getBasicProfile();
  console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
  console.log('Name: ' + profile.getName());
  console.log('Image URL: ' + profile.getImageUrl());
  console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.

  var id_token = { token: googleUser.getAuthResponse().id_token };

  // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log('user logged with google');
            window.location.href = "/user.html";
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Login failed");
        } else {
            console.log(this.responseText);
            console.log('did not take us to userhtml');
        }
    };

    xmlhttp.open("POST", "/userlogin", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify(id_token));

}

function onSignInOwner(googleUser) {
  var profile = googleUser.getBasicProfile();
  console.log('ID: ' + profile.getId()); // Do not send to your backend! Use an ID token instead.
  console.log('Name: ' + profile.getName());
  console.log('Image URL: ' + profile.getImageUrl());
  console.log('Email: ' + profile.getEmail()); // This is null if the 'email' scope is not present.

  var id_token = { token: googleUser.getAuthResponse().id_token };

  // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log('user logged with google');
            window.location.href = "/owner.html";
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Login failed");
        } else {
            console.log(this.responseText);
            console.log('did not take us to ownerhtml');
        }
    };

    xmlhttp.open("POST", "/ownerlogin", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify(id_token));

}

