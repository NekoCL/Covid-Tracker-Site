 // Open modal when user clicks button
document.getElementById("userCheckBtn").onclick = function() {
    document.getElementById("userCheckModal").style.display = "block";
};
document.getElementById("userHistBtn").onclick = function() {
    document.getElementById("userHistModal").style.display = "block";
};
document.getElementById("userProfileBtn").onclick = function() {
    document.getElementById("userProfileModal").style.display = "block";
};

// Clicking outside the modal box or clicking the (x) closes it
window.onclick = function(event) {
    //Click outside
    if (event.target == document.getElementById("userCheckModal")) {
      document.getElementById("userCheckModal").style.display = "none";
    }
    if (event.target == document.getElementById("userHistModal")) {
      document.getElementById("userHistModal").style.display = "none";
    }
    if (event.target == document.getElementById("userProfileModal")) {
      document.getElementById("userProfileModal").style.display = "none";
    }

    //Click x
    if (event.target == document.getElementById("close-check-x")) {
      document.getElementById("userCheckModal").style.display = "none";
    }
    if (event.target == document.getElementById("close-hist-x")) {
      document.getElementById("userHistModal").style.display = "none";
    }
    if (event.target == document.getElementById("close-prof-x")) {
      document.getElementById("userProfileModal").style.display = "none";
    }

};

/* Get usercheckin total for dashboard */
function getCheckInTotal() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

           checkin_table = JSON.parse(this.responseText);

           // display all data
           for(var i=0; i<checkin_table.length; i++){
                document.getElementById("total-checkin").innerHTML = checkin_table[i].totalcheck;
           }

        }
    };


    // Open connection to server
    xmlhttp.open("GET", "/totalcheckin", true);

    // Send request
    xmlhttp.send();

}

/* Get userInfo */
function getUserInfo() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

           user_table = JSON.parse(this.responseText);
           console.log('user_table '+JSON.parse(this.responseText));
           console.log(user_table);

           // display all data
           for(var i=0; i<user_table.length; i++){
                document.getElementById("blank-space").innerHTML = user_table[i].saveID; // output the ID from Users table

           }
        } else if (this.readyState == 4 && this.status >= 400) {
            alert("Get failed");
        }
    };


    // Open connection to server
    xmlhttp.open("GET", "/userinfo", true);

    // Send request
    xmlhttp.send();
}

/* Check In */
function userCheckIn(){

/*    var hold = req.session.idname;
    console.log('hold '+hold);*/

    var hold = document.getElementById("blank-space").innerHTML;
    var business_code = document.getElementById('user-check-in-code').value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Checked in!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to check in");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/checkinUser", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({hold, business_code}));
}


/* QR Decoder */
function decodeQR() {
   var qrDecode = require('/node_modules/qr-decode');
   var img = document.getElementById('imaging');
   qrDecode.decodeByDom(img, function (err, txt) {
        if (err) {
            return console.log(err);
        }
        console.log(txt);
});
}

/* Get User CheckIn history */
function getUserHistory() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log('responseText '+this.responseText);
            history_table = JSON.parse(this.responseText);
            console.log('history_table '+history_table);

            // Change null values in 'Yes-Column' to No
            for(var j=0; j<history_table.length; j++){
                if (history_table[j].yes_col===null) {
                    history_table[j].yes_col='No';
                }
            }

            // Clear history table area
            document.getElementById("user-history").innerHTML = '';

            // Add history to table
            for(var i=0; i<history_table.length; i++){
                document.getElementById("user-history").innerHTML += `<tr><td>`+history_table[i].date_time+`</td>
                                                                            <td>`+history_table[i].address+`</td>
                                                                            <td>`+history_table[i].yes_col+`</td></tr>`;
           }

        }
    };

    // Open connection to server
    xmlhttp.open("GET", "/userhistory", true);

    // Send request
    xmlhttp.send();

}

/* Get User Name under Welcome */
function getUserFirstName() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {

            user_table = JSON.parse(this.responseText);
            document.getElementById("greet_user").innerHTML = "Hey, " + user_table[0].first_name + " " + user_table[0].last_name + "!";

        }
    };

    // Open connection to server
    xmlhttp.open("GET", "/get_User", true);

    // Send request
    xmlhttp.send();

}

/* Get User Hotspot zips */
function getHotspotZips() {

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            console.log('responseText '+this.responseText);
            zip_table = JSON.parse(this.responseText);
            console.log('zip_table '+zip_table);

            // Clear hotspot zips area
            document.getElementById("hotspot-zips").innerHTML = '';

            // Add hotspot zips
            for(var i=0; i<zip_table.length; i++){
                document.getElementById("hotspot-zips").innerHTML += zip_table[i].hotspotzips + ', ';
           }

        }
    };

    // Open connection to server
    xmlhttp.open("GET", "/getuserhotspot", true);

    // Send request
    xmlhttp.send();

}

/* User Update Username */
function userUpdateUsername(){

    var usernameUp = document.getElementById("user_edit_username").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated username!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/updateUserUsername", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({usernameUp}));
}

/* User Update Email */
function userUpdateEmail(){

    var emailUp = document.getElementById("user_edit_email").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated email!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/updateUserEmail", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({emailUp}));
}

/* User Update First Name */
function userUpdateFirstname(){

    var firstUp = document.getElementById("user_edit_firstname").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated First Name!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/updateUserFirstname", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({firstUp}));
}

/* User Update Last Name */
function userUpdateLastname(){

    var lastUp = document.getElementById("user_edit_lastname").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated Last Name!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/updateUserLastname", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({lastUp}));
}

/* User Update Address */
function userUpdateAddress(){

    var addressUp = document.getElementById("user_edit_address").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated Address!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/updateUserAddress", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({addressUp}));
}

/* User Update Zip */
function userUpdateZip(){

    var zipUp = document.getElementById("user_edit_zip").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated Zip!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/updateUserZip", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({zipUp}));
}

/* User Update Birthday */
function userUpdateDOB(){

    var dobUp = document.getElementById("user_edit_dob").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated Date of Birth!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/updateUserDOB", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({dobUp}));
}

/* User Update Phone Number */
function userUpdatePhone(){

    var phoneUp = document.getElementById("user_edit_number").value;

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated Phone Number!");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/updateUserPhone", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({phoneUp}));
}

/* User Update Password */
function userUpdatePassword(){

    let passwords = {
        passUp: document.getElementById('user_edit_password').value,
        passCurrent: document.getElementById('user_current_password').value
    };

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Updated Password!");
        } else if (this.readyState == 4 && this.status == 401) {
            alert("Incorrect password");
        } else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failed to update");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/updateUserPassword", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify(passwords));
}

/* User Subscribe to Email Notifications */
function emailSubscribe(){

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Subscribed!");
        } else if (this.readyState == 4 && this.status == 406) {
            alert("Already subscribed!");
        }else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failure");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/emailsubscribe", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send();
}

/* User Unsubscribe from Email Notifications */
function emailUnsub(){

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();

    // Define function to run on response
    xmlhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            alert("Unsubscribed!");
        } else if (this.readyState == 4 && this.status == 406) {
            alert("Already unsubscribed!");
        }else if (this.readyState == 4 && this.status >= 400) {
            console.log('responseText2: '+this.responseText);
            alert("Failure");
        } else {
            console.log('ch else');
        }
    };

    // Open connection to server & send the post data using a POST request
    xmlhttp.open("POST", "/users/emailunsub", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send();
}