//Open modal to edit business
document.getElementById("owner-button").onclick = function() {
    document.getElementById("ownerModal1").style.display = "block";
};

document.getElementById("owner-button2").onclick = function() {
    document.getElementById("ownerModal2").style.display = "block";
};

document.getElementById("owner-button3").onclick = function() {
    document.getElementById("ownerModal3").style.display = "block";
};

document.getElementById("owner-button4").onclick = function() {
    document.getElementById("ownerModal4").style.display = "block";
};

// "Remove" button
document.getElementById("con-button").onclick = function() {
    document.getElementById("ownerModal5").style.display = "block";
};

document.getElementById("con-button2").onclick = function() {
    document.getElementById("ownerModal6").style.display = "block";
};

document.getElementById("con-button3").onclick = function() {
    document.getElementById("ownerModal7").style.display = "block";
};

document.getElementById("qrbtn").onclick = function() {
    document.getElementById("ownerModal8").style.display = "block";
};

document.getElementById("qrbtn2").onclick = function() {
    document.getElementById("ownerModal9").style.display = "block";
};

document.getElementById("qrbtn3").onclick = function() {
    document.getElementById("ownerModal10").style.display = "block";
};


// Clicking outside the modal box or clicking the (x) closes it
window.onclick = function(event) {
    //Click outside
    if (event.target == document.getElementById("ownerModal1")) {
      document.getElementById("ownerModal1").style.display = "none";
    }

    if (event.target == document.getElementById("ownerModal2")) {
      document.getElementById("ownerModal2").style.display = "none";
    }

    if (event.target == document.getElementById("ownerModal3")) {
      document.getElementById("ownerModal3").style.display = "none";
    }

    if (event.target == document.getElementById("ownerModal4")) {
      document.getElementById("ownerModal4").style.display = "none";
    }

    if (event.target == document.getElementById("ownerModal5")) {
      document.getElementById("ownerModal5").style.display = "none";
    }

    if (event.target == document.getElementById("ownerModal6")) {
      document.getElementById("ownerModal6").style.display = "none";
    }

    if (event.target == document.getElementById("ownerModal7")) {
      document.getElementById("ownerModal7").style.display = "none";
    }

    if (event.target == document.getElementById("ownerModal8")) {
      document.getElementById("ownerModal8").style.display = "none";
    }

    if (event.target == document.getElementById("ownerModal9")) {
      document.getElementById("ownerModal9").style.display = "none";
    }

    if (event.target == document.getElementById("ownerModal10")) {
      document.getElementById("ownerModal10").style.display = "none";
    }

    //Click x
    if (event.target == document.getElementById("closed-x4")) {
      document.getElementById("ownerModal1").style.display = "none";
    }
    if (event.target == document.getElementById("closed-x5")) {
      document.getElementById("ownerModal2").style.display = "none";
    }
    if (event.target == document.getElementById("closed-x6")) {
      document.getElementById("ownerModal3").style.display = "none";
    }
    if (event.target == document.getElementById("closed-x7")) {
      document.getElementById("ownerModal4").style.display = "none";
    }
    if (event.target == document.getElementById("closed-x8")) {
      document.getElementById("ownerModal5").style.display = "none";
    }
    if (event.target == document.getElementById("closed-x9")) {
      document.getElementById("ownerModal6").style.display = "none";
    }
    if (event.target == document.getElementById("closed-x10")) {
      document.getElementById("ownerModal7").style.display = "none";
    }
    if (event.target == document.getElementById("closed-x11")) {
      document.getElementById("ownerModal8").style.display = "none";
    }
    if (event.target == document.getElementById("closed-x12")) {
      document.getElementById("ownerModal9").style.display = "none";
    }
    if (event.target == document.getElementById("closed-x13")) {
      document.getElementById("ownerModal10").style.display = "none";
    }
};

function logoutowner(){

    // Create AJAX Request
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      window.location.href = "/index.html";
    }
  };

    // window.location.href = "/index.html";
    xmlhttp.open("POST", "/logout", true);
    xmlhttp.send();

}

/*function startPage() {
  var xmlhttp = new XMLHttpRequest();

   xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      //implement call back function
      document.getElementById("first_card_owner").innerHTML = xmlhttp.responseText;
    }
  };

  xmlhttp.open("GET", "/startownerpage", true);
  xmlhttp.send();

}*/

/* Generate QR Function */

function qrbun() {

    var render_code = document.getElementById("code_1").innerHTML;

    //var use_this = JSON.stringify(render_code);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      console.log('qr code route is working');
      document.getElementById("get_qr").innerHTML = this.responseText;
    }
  };
    xmlhttp.open("POST", "/qr_biz", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({render_code}));
}

function qrbun2() {

    var render_code2 = document.getElementById("code_2").innerHTML;

    //var use_this = JSON.stringify(render_code);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      console.log('qr code route is working');
      document.getElementById("get_qr2").innerHTML = this.responseText;
    }
  };
    xmlhttp.open("POST", "/qr_biz2", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({render_code2}));
}

function qrbun3() {

    var render_code3 = document.getElementById("code_3").innerHTML;

    //var use_this = JSON.stringify(render_code);
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      console.log('qr code route is working');
      document.getElementById("get_qr3").innerHTML = this.responseText;
    }
  };
    xmlhttp.open("POST", "/qr_biz3", true);
    xmlhttp.setRequestHeader("Content-type", "application/json");
    xmlhttp.send(JSON.stringify({render_code3}));
}
